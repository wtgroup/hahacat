package org.xxz.test;

import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.xxz.Application;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class TestJdbc {
    
    private static final Logger log = LoggerFactory.getLogger(TestJdbc.class);
    
    @Resource
    private JdbcTemplate jdbcTemplate;
    
    @Rollback(true)
    @Test
    public void testInsert() throws Exception {
        String sql = "insert into test(id, username, password) value (?, ?, ?)";
        int row = jdbcTemplate.update(sql, new Object[]{null, "水门1", "123"});
        assertEquals(1, row);
        log.info("--------------- test jdbc---------");
    }

}
