package org.xxz.test;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.xxz.Application;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = WebEnvironment.RANDOM_PORT)
public class TestHelloController {
    
    @Resource
    private TestRestTemplate testRestTemplate;
    
    @Test
    public void testHello1() throws Exception {
        String string = testRestTemplate.getForObject("/hello1", String.class);
        Assert.assertEquals("helloworld", string);
    }
    
    @Test
    public void testHello2() throws Exception {
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        
        // 这里不能用map ？？？
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("a", "a1");
        params.add("b", "b1");
        
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(params, headers);
        
        ResponseEntity<String> responseEntity = testRestTemplate.exchange("/hello2", HttpMethod.POST, requestEntity, String.class);
        String body = responseEntity.getBody();
        JSONObject jsonObject = JSONObject.parseObject(body);
        Assert.assertEquals("a1", jsonObject.getString("a"));
        
    }
    
    @Test
    public void testHello3() throws Exception {
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        
        // 这里不能用map ？？？
        Map<String, Object> params = new HashMap<>();
        params.put("a", "a1");
        params.put("b", "b1");
        
        // 建议传string
        String string = JSON.toJSONString(params);
        
        HttpEntity<String> requestEntity = new HttpEntity<>(string, headers);
        
        ResponseEntity<String> responseEntity = testRestTemplate.exchange("/hello3", HttpMethod.POST, requestEntity, String.class);
        String body = responseEntity.getBody();
        System.out.println("body:" + body);
        JSONObject jsonObject = JSONObject.parseObject(body);
        Assert.assertEquals("a1", jsonObject.getString("a"));
        
    }

}
