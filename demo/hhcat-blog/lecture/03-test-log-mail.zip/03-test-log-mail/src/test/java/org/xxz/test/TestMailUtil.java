package org.xxz.test;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.xxz.Application;
import org.xxz.mail.MailUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class TestMailUtil {
    
	@Autowired
	MailUtil mailUtil;
	
	String to = "xxzkid@sina.com";
	
	@Test
	public void testSendText() throws Exception {
		mailUtil.sendText(to, "测试text", "测试text");
	}
	
	@Test
	public void testSendHtml() throws Exception {
		mailUtil.sendHtml(to, "测试html", "<h1>测试html</h1>");
	}
	
	@Test
	public void testSendAttachments() throws Exception {
		mailUtil.sendAttachments(to, "测试attachments", "测试attachments", "d:\\attachments.txt");
	}
	
	@Test
	public void testSendInlineResource() throws Exception {
		// 注意图片的src=cid:xxx 与后面的要对应
		mailUtil.sendInlineResource(to, "测试inlineResource", "测试inline resource<img src=\"cid:001\">", "d:\\ihehe.jpg", "001");
	}
}