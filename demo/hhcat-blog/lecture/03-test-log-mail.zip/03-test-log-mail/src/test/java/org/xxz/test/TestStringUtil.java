package org.xxz.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestStringUtil {
    
    @Test
    public void testFirstCharUpperCase1() throws Exception {
        String string = StringUtil.firstCharUpperCase("abc");
        assertEquals("Abc", string);
        System.out.println("---- case 1 end ---");
    }
    
    @Test
    public void testFirstCharUpperCase2() throws Exception {
        String string2 = StringUtil.firstCharUpperCase("");
        assertEquals("", string2);
        System.out.println("--- case 2 end ---");
    }
    
    @Test
    public void testFirstCharUpperCase3() throws Exception {
        String string3 = StringUtil.firstCharUpperCase("a");
        assertEquals("A", string3);
        System.out.println("--- case 3 end ---");
    }
    
}
