package org.xxz.test;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestExample {
    
    private static int value = 8;
    
    /*
    @Before
    public void setUp() {
        value += 1;
        System.out.println("--- setUp Before---");
    }
    */
    
    static ClassPathXmlApplicationContext ctx = null;
    
    /**/
    @BeforeClass
    public static void setUp() {
        
        value += 1;
        System.out.println("--- setUp BeforeClass---");
    }
    
    
    @Test
    public void testValue() throws Exception {
        value += 1;
        Assert.assertEquals(10, value);
        System.out.println("--- test value 1 ---");
    }
    
    @Ignore
    @Test
    public void testValue2() throws Exception {
        value += 2;
        Assert.assertEquals(12, value);
        System.out.println("--- test value 2 ---");
    }
    
    /*
    @After
    public void tearDown() throws Exception {
        System.out.println("--- after ---");
    }
    */
    
    @AfterClass
    public static void tearDown() throws Exception {
        System.out.println("--- afterclass---");
        if (ctx != null)
            ctx.close();
    }
    
}
