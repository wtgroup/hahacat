package org.xxz.test.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    
    @RequestMapping(value = "/hello1")
    public String hello1() {
        return "helloworld";
    }
    
    @RequestMapping(value = "/hello2")
    public Map<String, Object> hello2(String a, String b) {
        Map<String, Object> map = new HashMap<>();
        map.put("a", a);
        map.put("b", b);
        return map;
    }
    
    @RequestMapping(value = "/hello3")
    public Map<String, Object> hello3(@RequestBody Map<String, Object> map) {
        return map;
    }

}
