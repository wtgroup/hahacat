package org.xxz.test;

/**
 * 字符串工具类
 * @author tt
 *
 */
public final class StringUtil {
    
    private StringUtil() {}
    
    /**
     * 字符串首字母大写
     * @param str
     * @return
     */
    public static String firstCharUpperCase(String str) {
        /**/
        if (str == null) {
            return null;
        }
        
        if ("".equals(str.trim())) {
            return str;
        }
        
        String c = str.charAt(0) + "";
        String firstChar = c.toUpperCase();
        return firstChar + str.substring(1);
    }

}
