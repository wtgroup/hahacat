package org.xxz.mvcvelocity.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.velocity.VelocityConfig;
import org.springframework.web.servlet.view.velocity.VelocityConfigurer;
import org.springframework.web.servlet.view.velocity.VelocityViewResolver;

@SuppressWarnings("deprecation")
@Configuration
public class WebConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "spring.velocity")
    public VelocityConfig velocityConfig() {
        return new VelocityConfigurer();
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.velocity")
    public VelocityViewResolver viewResolver() {
        return new VelocityViewResolver();
    }

}
