package org.xxz.mvcvelocity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {
    
    @RequestMapping(value = {"/index"})
    @ResponseBody
    public String index() {
        return "hello, mvc-velocity";
    }
    
    @RequestMapping(value = {"/", ""})
    public ModelAndView index2() {
        ModelAndView mv = new ModelAndView("index");
        mv.addObject("user", "水门");
        return mv;
    }
    
    @RequestMapping(value = {"test"})
    public String test(ModelMap map) {
        map.put("user", "水门2");
        return "index";
    }

}
