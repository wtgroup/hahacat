package org.xxz.test.domain;

import lombok.Data;

@Data
public class User {
    
    private Long id;
    private String name;

}
